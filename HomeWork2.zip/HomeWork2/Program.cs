﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Анна Гусак 

namespace HomeWork2
{
    class Program
    {

        #region 1.MinValue

        /* Написать метод, возвращающий минимальное из трех чисел.*/

        static int MinValue(int x, int y, int z)
        {
            int min;
            if (x <= y && x <= z)
                min = x;
            else if (y <= x && y <= z)
                min = y;
            else
                min = z;

            return min;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Введите числа x y z: ");
            string s1 = Console.ReadLine();
            string[] values1 = s1.Split(' ');
            int x = int.Parse(values1[0]);
            int y = int.Parse(values1[1]);
            int z = int.Parse(values1[2]);
            Console.WriteLine($"Из чисел {x}, {y} и {z} минимальным будет {MinValue(x, y, z)}");

        }

        #endregion

        #region 2.NumberOfDigits

        /*  Написать метод подсчета количества цифр числа.*/

        static int NumberOfDigits(long n)
        {
            int k = 0;
            while (n % 10 != 0)
            {
                k++;
                n /= 10;
            }
            return k;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Введите число: ");
            long x = long.Parse(Console.ReadLine());
            Console.WriteLine($"количество цифр в числе {x} равно {NumberOfDigits(x)}");
        }
        #endregion

        #region 3.Sum

        /* С клавиатуры вводятся числа, пока не будет введен 0. Подсчитать сумму всех нечетных положительных чисел.*/

        static void Main(string[] args)
        {
            long sum = 0;
            int a;
            do
            {
                Console.WriteLine("Введите число: ");
                a = int.Parse(Console.ReadLine());
                if ((a % 2 != 0) && (a > 0))
                {
                    sum += a;
                }
            }
            while (a != 0);
            Console.WriteLine($"Сумма положительных нечетных чисел равна {sum}");
            Console.ReadLine();
        }
        #endregion

        #region 4.LoginPassword

        /*Реализовать метод проверки логина и пароля. На вход подается логин и пароль. 
         * На выходе истина, если прошел авторизацию, и ложь, если не прошел (Логин: root, Password: GeekBrains). 
         * Используя метод проверки логина и пароля, написать программу: пользователь вводит логин и пароль, 
         * программа пропускает его дальше или не пропускает. С помощью цикла do while ограничить ввод пароля тремя попытками.*/

        static void Main(string[] args)
        {
            int i = 0;
            do
            {
                Console.WriteLine("Введите логин: ");
                string login = Console.ReadLine();
                string loginOrigin = "root";
                bool resultLogin = login.Equals(loginOrigin);

                Console.WriteLine("Введите пароль: ");
                string password = Console.ReadLine();
                string passwordOrigin = "GeekBrains";
                bool resultPassword = password.Equals(passwordOrigin);

                if (resultLogin && resultPassword)
                {
                    Console.WriteLine("Вы успешно зашли в систему.");
                    break;
                }
                else
                    Console.WriteLine("Логин или пароль введены не верно.");
                i++;
            }
            while (i <= 3);
        }
        #endregion

        #region 5.IBMRecommendation

        /* а) Написать программу, которая запрашивает массу и рост человека, вычисляет его индекс массы и сообщает, 
         *    нужно ли человеку похудеть, набрать вес или все в норме;
           б) Рассчитать, на сколько кг похудеть или сколько кг набрать для нормализации веса.*/

        static void Main(string[] args)
        {
            Console.WriteLine("Введите ваш вес: ");
            double weight = double.Parse(Console.ReadLine());
            Console.WriteLine("Введите ваш рост в метрах: ");
            double height = double.Parse(Console.ReadLine());
            double IBM = weight / (height * height);

            double normalMin = (18.5 * height * height) - weight;
            double normalMax = weight - (24.9 * height * height);

            if (IBM < 18.5)
                Console.WriteLine($"Ваш IBM равен {IBM.ToString("F1")} и вес ниже нормального. Вам следует набрать {normalMin.ToString("F1")} кг.");
            else if (IBM >= 18.5 && IBM < 25)
                Console.WriteLine($"Ваш IBM равен {IBM.ToString("F1")} и у вас нормальный вес. ");
            else if (IBM >= 25 && IBM < 30)
                Console.WriteLine($"Ваш IBM равен {IBM.ToString("F1")} и у вас избыточный вес. Вам следует сбросить {normalMax.ToString("F1")} кг.");
            else if (IBM >= 30 && IBM < 35)
                Console.WriteLine($"Ваш IBM равен {IBM.ToString("F1")} и у вас ожирение 1 степени. Вам следует сбросить {normalMax.ToString("F1")} кг.");
            else if (IBM >= 35 && IBM < 40)
                Console.WriteLine($"Ваш IBM равен {IBM.ToString("F1")} и у вас ожирение 2 степени. Вам следует сбросить {normalMax.ToString("F1")} кг.");
            else
                Console.WriteLine($"Ваш IBM равен {IBM.ToString("F1")} и у вас ожирение 3 степени. Вам следует сбросить {normalMax.ToString("F1")} кг.");

            Console.ReadLine();

        }
        #endregion

        #region 6.GoodNumbers

        /* Написать программу подсчета количества «Хороших» чисел в диапазоне от 1 до 1 000 000 000. 
        * Хорошим называется число, которое делится на сумму своих цифр. 
        * Реализовать подсчет времени выполнения программы, используя структуру DateTime.*/

        static int SumOfDigits(int x)
        {
            int sumOfDigits = 0;

            while (x != 0)
            {
                sumOfDigits += x % 10;
                x /= 10;
            }
            return sumOfDigits;
        }

        static void Main(string[] args)
        {
            DateTime start = DateTime.Now;

            int counter = 0;

            for (int number = 1; number < 1000000000; number++)
            {
                if ((number % SumOfDigits(number)) == 0)
                {
                    Console.WriteLine($"число {number} является хорошим");
                    counter++;
                }
            }
            DateTime finish = DateTime.Now;
            Console.WriteLine($"Длительность выполнения программы: {finish - start}");
        }
        #endregion

        #region 7.ABNumbers

        /* Разработать рекурсивный метод, который выводит на экран числа от a до b (a<b) */

        static void Main(string[] args)
        {
            Loop(3, 13);

            static void Loop(int a, int b)
            {
                Console.Write("{0,4} ", a);
                if (a < b)
                    Loop(a + 1, b);
            }

        }
        #endregion
    }
}
